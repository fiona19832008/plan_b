
%
%  SYNOPSIS:
%
%    This MATLAB script demonstrate the DOA (direction of arrival) estimation
%    for antenna array data with missing entries, and interference from
%    unexpected sources away from the directions of interest. 
%
%    This problem is equivalent two sub problems: 
%    1. multi-dimensional spectral estimation problem with missing 
%    entries. 
%    2. interference mitigation in spectral estimation.
%
%    Both the sub-problems were studied much before, but we are not aware of
%    any work where both the problem were dealt simultaneously.
%
%    MUSIC is the most efficient (and popular) algorithms for 
%    multi-dimensional spectral estimation (and also DOA) problem. MUSIC
%    requires identify the signal space and the noise space. In case there is
%    no data missing singular value decomposition can be employed to obtain
%    it. In case there are missing data, we identify the signal space by 
%    a low rank approximation of the weighted data set. The missing
%    entries are assigned a weight 0, and rest are assigned a weight 1.  
%    Further more to supress interferences by waves that comes from
%    (or gets reflected from) sources away from the direction of interest,
%    we estimate signal subspace with regularization using a priori 
%    information that the sources of interest are close to zenith.
%    We use our routine 'biSVD_weighted_regularized' for this purpose.
%
%    Following steps are done in the script:
%    0. Set MATLAB path and other features.
%    1. Setup all the parameters for simulation and estimation.
%    2. Simulate sensor data.
%    3. Estimate the range of signal space using: 
%           "SVD with imputed values" 
%           and
%           "low rank approximation with missing data (biSVD_weighted)" 
%    4. Project pure frequencies (over a fine grid) to obtain the gain.
%    5. Plot gain function.
%
%  BUG REPORT:
%
%    saptarshi.das@univie.ac.at
%

%
%  LAST MODIFIED:
%
%    Jan. 19, 2011

help demo_DOA_2

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MATLAB SPECIFIC SETUP
%

clear all
setup
format short e 
rand('seed', 0);
randn('seed', 0);
fprintf('PROCESSING: \n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SIMULATION AND ESTIMATION RELATED SETUP
%
%  %% ANTENNA ARRAY DATA SIMULATION PARAMETERS
%
%  nA            number of sensors (antenna) in the array.
%  dA            distance between sensors (antenna).
%  nT            total number of time points. 
%  lambda        wavelength of frequency emitted by the sources.
%  P             potentials of each source (vector).
%  theta         angle of arrival of each rource (vector) in "DEGREE". 
%  sigma         standard deviation of the additive white Gaussian noise.
%
%  %% AMOUNT OF RANDOM MISSING DATA SIMULATION PARAMETER
%
%  miss_frac     fraction of values that will be missing.  
%
%  %% ESTIMATION REALTED SETUP 
%
%  min_theta     smallest angle to check if frequency is in signal space.
%  max_theta     largest angle to check if frequency is in signal space.
%  d_theta       resolution between min_theta and max_theta.
%  n_iter        number of iterations in iterative low rank app. algos.

 
nA           = 20; 
dA           = .1; 
nT           = 200; 
lambda       = 1; 
P            = 10*[2; 3; 3; 3; 2]; 
theta        = [30; 80; 90; 100; 150]; 
sigma        = 2; 
miss_frac    = 0.2;
min_theta    = 0; 
max_theta    = 180; 
d_theta      = .2; 
n_iter       = 30;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SIMULATE ARRAY SIGNALS
%

fprintf('Simulating antenna array data with given parameters ...\n')
A = simulate_array_signal(nA, dA, nT, lambda, P, theta, sigma);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MAKE SPECIFIED AMOUNT OF DATA MISSING AT RANDOM POSITIONS
%
%  ** A weight matrix 'W' with binary entries are generated.
%     The entries in 'A' corresponding to weight 0 in 'W' are
%     considered as missing.
%

fprintf('Simulating pattern of missing data ...\n')
R = rand(nT, nA);
S = sort(R(:));
[I, J] = find(R <= S(ceil((1 - miss_frac)*nT*nA)));
W = sparse(I, J, 1); W = full(W);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SIGNAL SUBSPACE FOR MUSIC (IMPUTED MISSING DATA) 
%
%  ** impute missing values with zero, and the use
%     MATLAB svd to compute the subspace.

fprintf('Estimating signal subspace using SVD ...\n')
fprintf('(missing data are imputed with 0)\n')
A = A.*W; 
[U, D, V] = svd(A);
V_sig     = V(: , 1: length(P));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SIGNAL SUBSPACE FOR MUSIC (WEIGHTED LOW RANK APPROACH) 
%
%  ** The signal subspace is estimated from the weighted
%     low rank approximation of the data set. The data identified 
%     as missing (or not useful) values are set to weight 0, and
%     good data points are set to weight 1. 

fprintf('Estimating signal subspace using weighted low rank approximation...\n')
fprintf('(using biSVD_weighted routine)\n')
param.niter      = n_iter;
param.regu_left  = 0.0*nT;
param.regu_right = .005*nA;
[U_w, D_w, V_w] = BIRSVD2(A, W, length(P), param);
V_sig_w = V_w;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  CHECK GAIN ON A FINE GRID
%

test_angle = [min_theta:d_theta:max_theta];
test_vec = -sqrt(-1)*(2*pi*dA/lambda)*cos(test_angle.'*pi/180)*([0:nA-1]);
test_vec = exp(test_vec);
test_vec_fro = sum((test_vec .* conj(test_vec)), 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PROJECT ON NOISE SPACE VIA SIGNAL SPACE 
%  TO COMPUTE THE GAIN
%  (IMPUTED MISSING DATA)
%

fprintf('Computing gain functions ...\n')
P_sig = V_sig' * test_vec';
P_no  = test_vec_fro' - sum(P_sig.*conj(P_sig),1); 
gain  = 1./P_no;
gain  = gain./max(gain);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PROJECT ON NOISE SPACE VIA SIGNAL SPACE
%  TO COMPUTE THE GAIN
%  (WEIGHTED LOW RANK APPROXIMATION)
%

P_sig_w = V_sig_w' * test_vec';
P_no_w  = test_vec_fro' - sum(P_sig_w.*conj(P_sig_w),1); 
gain_w  = 1./P_no_w;
gain_w  = gain_w./max(gain_w);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PLOT GAIN FUNCTIONS 
%

fprintf('Plotting gain functions ...\n')
fullscreen = get(0,'ScreenSize');
figure('Position',[0 150 fullscreen(3) fullscreen(4)])

subplot(2, 1, 1)
plot(test_angle, gain)
title('gain function of P-MUSIC with imputed missing values', ...
      'fontweight', 'bold')
xlabel('Angle of arrival in degree')
ylabel('Normlized power')
plot_finish
grid minor

subplot(2, 1, 2)
plot(test_angle, gain_w)
title(...
   'gain function of P-MUSIC with regularized weighted low rank approach', ...
   'fontweight', 'bold')
xlabel('Angle of arrival in degree')
ylabel('Normlized power')
plot_finish
grid minor

fprintf('Plotting missing data pattern ...\n')
figure('Position',[0 -50 100 900])
imagesc(W)
ylabel('pattern of missing values')
colormap gray
axis tight
axis equal

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MORE INFO
%

fprintf('\n')
fprintf('MORE INFO: \n')
fprintf('No. of antenna in the array ---------- %d\n', nA)
fprintf('No. of time points ------------------- %d\n', nT)
fprintf('No. of source (reflector) ------------ %d\n', 1)
fprintf('No. of source interfearing ----------- %d\n', length(P) -1)
fprintf('Wavelength of incoming signal -------- %f\n', lambda)
fprintf('Gaussian additive noise (sigma) ------ %f\n', sigma)
fprintf('Fraction of missing values ------------%f\n', miss_frac)
