%
%  SYNOPSIS: 
%  
%  MATLAB script to demonstrate the BIRSVD routine on an image 
%  inpainting problem. An wide field astronomical image observed in the
%  optical bandwidth is considered for this example. The astronomical image
%  has a smooth background structure, and the task is to estimate the
%  backgound and correct it. 
%
%  Along with image data, a binary weight matrix is also provided. This
%  weight file distinguishes the pure background pixels with the smooth
%  background structure from the bright objects, bad pixels etc.. Note that 
%  such weight files easy to generate for astronomical images, as extensive
%  catelogues of celestial objects are available, and bad pixel map of 
%  astronomical imaging sensors are also available. Also, this way of 
%  identifying background is a standard procedure in astronomical image
%  processing softwares (e.g. IRIS / IRAF).
%
%  Once the pixels corresponding to the background is identified, the 
%  problem is now image inpainting problem. We compute a regularized
%  low rank approximation of the background pixels in order to estimate 
%  the background, especially at the pixels where the background information
%  is missing.
%
%  There are several algorithms developed specially for image inpainting. 
%  
%  This demonstration script can also be used to show that the BIRSVD 
%  consistently converges to a single point. On the other hand if the
%  same low rank approximation is done with biSVD_weighted (which do not
%  employ any regualrization), the results converges to different points
%  while started from a different point. 
%
%  Since out of sample data about the background is not available, we 
%  cannot demonstrate the fidelity of the reconstruction over unobserved
%  pixels. To check the fidelity of reconstruction on out of sample data
%  use the following demo scripts: quick_compare_BIRSVD_FPCA.m,
%  detail_compare_BIRSVD_FPCA.m.

% AUTHOR/BUG REPORT:
% 
% saptarshi.das@univie.ac.at
%	

help driver_astro_image

clear all
format short e
clf
setup

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	DATA ACUQUISITION 
%

fprintf('Loading data ... \n');
data  = fitsread('r.VIMOS.2005-09-12T09:33:32.845_0000.fits');
mask  = 1 - fitsread('r.VIMOS.2005-09-12T09:33:32.845_obj_mask.fits');
mask1 = 1 - fitsread('r.VIMOS.2005-09-12T09:33:32.845_bpm.fits');
mask  = mask .* mask1;
% 
data = data(200: end-200, 200: end-200);
mask = mask(200: end-200, 200: end-200);
% [data, mask] = extract_object(data, 5, 90);
% mask = (1 - mask);
% mask  = mask2 .* mask1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	MEAN CORRECTION
%

% data_mean = sum(sum(data .* mask)) / (sum(sum(mask)));
data_mean = 0;
data = data - data_mean;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	PARAMETER SETUP
%
%	R		rank of approximation, only R singular values retain.
%	N_iter		Number of iterations.
%	ini_met		method for choosing initial left singular vectors. 

R                       = 4;
param.N_iter            = 50;
% ini_met    = 'zeroOneVectors';
param.ini_met           = 'randOrthoNormal';
param.regu_type_left    = '2ndOrderDiff_acc8';
param.regu_left         = 10; 
param.regu_type_right   = '2ndOrderDiff_acc8';
param.regu_right        = 10;
% ini_met    = 'polyOrthoNormal';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	MAIN FUNCTION CALL
%
%	U	left singular vectors, R of them.
%	S	singular values, with R non-zeros diagonal entries.
%	U	right singular vectors, R of them.

fprintf('Problem size:   %d rows, %d columns: \n', ...
        size(mask, 1), size(mask, 2));
fprintf('Calling main function ... \n');
[U, S, V, ERR]  = BIRSVD(data, mask, R, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  ** inferior methods, add more comments,
% [U, S, V]  = biSVD_weighted(data, mask, R, param);
% [U, S, V]  = biSVD(data, param.N_iter, R, param.ini_met);
% [U, S, V]  = svds(data, R);
% use imputation

R_app = 4;
recon_data = U(:, 1:R_app)*S(1:R_app, 1:R_app)*[V(:, 1:R_app)]' + ...
             0.0*data_mean;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	ERROR ESTIMATE
%

diff_data       = (data - recon_data) .* (mask);
diff_test       = (data - recon_data) .* (1 - mask);
sqr_diff   = diff_data.^2;
L2_err     = sqrt(sum(sum(sqr_diff)));
L2_err_nor = L2_err / norm(data.*mask, 'fro'); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	PLOTS AND RESULTS
%

fprintf('RESULTS: \n');
fprintf('Normalized reconstruction error:  %f\n', L2_err_nor);
fprintf('Plotting results... \n');
subplot(2, 2, 1)
  imagesc(data)
  colorbar
  title('The actual data matrix', 'fontweight', 'bold')
subplot(2, 2, 2)
  imagesc(mask)
  colorbar
  title('Sampling points', 'fontweight', 'bold')
subplot(2, 2, 3)
  imagesc(recon_data)
  colorbar
  title('The reconstructed data matrix', 'fontweight', 'bold')
colormap('gray')
subplot(2, 2, 4)
  hist(diff_test, 1000)
  title('Distribution of Noise', 'fontweight', 'bold')


% CHANGE LOG 
%
%  Aug. 31, 2011 -- modifed the description.
%  Aug. 03, 2010 -- first key in. 
