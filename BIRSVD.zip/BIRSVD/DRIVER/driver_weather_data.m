
%
%  SYNOPSIS:
%
%  This MATLAB script demonstrate the capability of the routine
%  BIRSVD for matrix completion with noise. As an a priori information
%  BIRSVD requires the data matrix to be of low rank, and smooth in
%  either (or both) dimensions.
%
%  In this demonstration, 48 hr. temperature data sampled each half an
%  hour over 20 cities are used as test data. Consider that (m, n)
%  entry of the matrix represent the mth measurement for the nth
%  city. As an a priori information, we use the fact that temperature
%  vary smoothly over time. Hence, we sought for a low rank approximation
%  where the left approximant is smooth. For this example data set, we
%  use a rank 2 approximation.
% 
%  This routine reports a detail comparision, and require some time for
%  its completion.
%
%  For each sample size, several random sampling patterns are generated.
%  The results are avarage over all this random sampling patterns.
%  The results are presented as out of sample normalized mean square
%  error (NMSE) expressed in dB.
%  

%
%  BUG REPORT:
%
%    saptarshi.das@univie.ac.at
%

help detail_compare_BIRSVD_FPCA 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MATLAB SPECIFIC SETUP
%

clear all
setup
format short e 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  ALGORITHM SPECIFIC SETUP
%
%
%  miss_frac     fraction of values that will be missing.  
%  n_iter        number of iterations in iterative low rank app. algos.
%  rnk           rank of approximation.
%  lambda        regularization parameter.
%  max_samp      for statistical results, maximum number of sampling iteration. 
%  N_miss        no. of missing patterns with different missing fraction.

 
n_iter       = 50;
rnk          = 2;
lambda       = .006;
max_samp     = 50;
N_miss       = 8;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  LOAD DATA
%
%  Tmp    the variable in which the temperature data of
%         20 cities is loaded.
%
%  N_m    no. of measurements.
%
%  N_c    no. of cities.

fprintf('Loading data ... \n');
load temperature;
[N_m, N_c] = size(Tmp);

fprintf('PROCESSING ... \n')
fprintf('COMPLETE: 0 %% | ')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  INITIALIZE OUTPUT VARIABLES
%
%  ERR_REG_IN     normalized error, within data, using regularization.
%  ERR_REG_OUT    normalized error, out of data, using regularization. 
%  ERR_FPCA_IN    normalized error, within data, FPCA algorithm.
%  ERR_FPCA_OUT   normalized error, out of data, FPCA algorithm. 

ERR_REG_IN   = zeros(max_samp, N_miss); 
ERR_REG_OUT  = zeros(max_samp, N_miss);

for miss = 1 : N_miss

  miss_frac = 1 - (.3 + (miss -1)*.05);

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %
  %  LOOP OVER SEVERAL TIMES TO COMPUTE THE STATISTICAL ERROR
  %
      
  for itr = 1 : max_samp 
  
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    %  MAKE SPECIFIED AMOUNT OF DATA MISSING AT RANDOM POSITIONS
    %
    %  ** A weight matrix 'W' with binary entries are generated.
    %     The entries in 'A' corresponding to weight 0 in 'W' are
    %     considered as missing.
    %
  
    % fprintf('Simulating pattern of missing data ...\n')
    sp_chk = 1;
    while sp_chk == 1
      R = rand(N_m, N_c);
      S = sort(R(:));
      [I, J] = find(R <= S(ceil((1 - miss_frac)*N_m*N_c)));
      W = sparse(I, J, 1); W = full(W);
      if (size(W, 1) == N_m) && (size(W, 2) == N_c) 
        sp_chk = 0;
      end
    end
    
  

  
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    %  COMPUTE REGULARIZED LOW RANK APPROXIMATION
    %
    
    param.niter           = n_iter;
    param.regu_type_left  = '2ndOrderDiff_acc8';
    param.regu_type_right = 'Tikh';
    param.regu_left       = lambda; 
    param.regu_right      = .000;
    
    [U_reg, D_reg, V_reg] = BIRSVD(Tmp, W, rnk, param);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    %  FIDELITY WITHIN DATA, AND OUT OF DATA
    %
    
    Tmp_reg_rec  = U_reg * D_reg * V_reg';
    
    ERR_REG_IN(itr, miss )  = norm((Tmp - Tmp_reg_rec).*W, 'fro') ...
                     / norm(Tmp.*W, 'fro');
    ERR_REG_OUT(itr, miss) = norm((Tmp - Tmp_reg_rec).*(1 -W), 'fro') ...
                     / norm(Tmp.*(1 -W), 'fro');
    
  end
  avg_err_reg_in   = mean(ERR_REG_IN(:, miss));   
  avg_err_reg_out  = mean(ERR_REG_OUT(:, miss));  

  fprintf('%d %% | ', floor(100*miss/N_miss))
end

fprintf('\n')
fprintf('Generating plots ...\n')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PLOTTING SPECIFICATION
%
%  lw       line width
%  fs       font size
%  fw       font weight
%  ms       marker size

lw = 2;
fs = 10;
fw = 'bold';
ms = 6;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  PLOTS  
%

plot([30:5:55], 10*log10(mean(ERR_REG_OUT(:, 1:6))), 'ro-', ...
     'linewidth', lw, 'markersize', ms)
hold on
plot([30:5:55], 10*log10(mean(ERR_REG_IN(:, 1:6))), 'b*-', ...
     'linewidth', lw, 'markersize', ms)

legend('Out of sample', 'Within sample')
grid on

xlabel('Sample size in percent', 'fontsize', fs, 'fontweight', fw)
ylabel('NMSE [dB]', 'fontsize', fs, 'fontweight', fw)
title('Using BIRSVD on weather data ', 'fontsize', fs, 'fontweight', fw)


plot_finish


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SAVE DATA
%

% save compare_results  ERR_REG_IN ...
%                       ERR_REG_OUT ...
%                       ERR_FPCA_IN ...
%                       ERR_FPCA_OUT
%
% saveas(gcf, 'fpca_compare', 'epsc')

%
%  CHANGE LOG:
%
%  Aug. 31, 2011 -- check if FPCA software is available.
%  Aug. 23, 2011 -- copied from demo_weather.m, and first key in.
