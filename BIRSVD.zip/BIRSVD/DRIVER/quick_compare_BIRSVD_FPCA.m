
%
%  SYNOPSIS:
%
%  This MATLAB script demonstrate the capability of the routine
%  BIRSVD for matrix completion with noise. As an a priori information
%  BIRSVD requires the data matrix to be of low rank, and smooth in
%  either (or both) dimensions.
%
%  For the purpose of comparsion, the FPCA algorithm by Ma et al. is used.
%  FPCA computes a low rank approximation using a priori information that
%  the nuclear norm of the matrix is bounded.
%
%  In this demonstration, 48 hr. temperature data sampled each half an
%  hour over 20 cities are used as test data. Consider that (m, n)
%  entry of the matrix represent the mth measurement for the nth
%  city. As an a priori information, we use the fact that temperature
%  vary smoothly over time. Hence, we sought for a low rank approximation
%  where the left approximant is smooth. For this example data set, we
%  use a rank 2 approximation.
% 

%
%  BUG REPORT:
%
%    saptarshi.das@univie.ac.at
%


help quick_compare_BIRSVD_FPCA 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MATLAB SPECIFIC SETUP
%

clear all
setup
if (exist('FPCA_MatComp') == 0)
  fprintf('FPCA SOFTWARE MISSING:\n')
  fprintf('The software FPCA is not available in current MATLAB path. \n')
  fprintf('You can download the software from:\n')
  fprintf('http://www.columbia.edu/~sm2756/FPCA.htm\n')
  fprintf('Unpack the software, and add to MATLAB path. \n')
  fprintf('OR, unpack the FPCA software inside BIRSVD folder, setup \n')
  fprintf('inside BIRSVD will automatically add FPCA to MATLAB path. \n')
  return
end
format short e 
fprintf('PROCESSING: \n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  ALGORITHM SPECIFIC SETUP
%
%
%  miss_frac     fraction of values that will be missing.  
%  n_iter        number of iterations for BIRSVD.

 
miss_frac    = 0.70;
n_iter       = 50;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  LOAD DATA
%
%  Tmp    the variable in which the temperature data of
%         20 cities is loaded.
%
%  N_m    no. of measurements.
%
%  N_c    no. of cities.

fprintf('Loading data ... \n');
load temperature;
[N_m, N_c] = size(Tmp);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  MAKE SPECIFIED AMOUNT OF DATA MISSING AT RANDOM POSITIONS
%
%  ** A weight matrix 'W' with binary entries are generated.
%     The entries in 'A' corresponding to weight 0 in 'W' are
%     considered as missing.
%

fprintf('Amount of sample used (in percent):  %d\n', ...
        floor((1-miss_frac)*100));
fprintf('Simulating sampling pattern ...\n')
R = rand(N_m, N_c);
S = sort(R(:));
[I, J] = find(R <= S(ceil((1 - miss_frac)*N_m*N_c)));
W = sparse(I, J, 1); W = full(W);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  COMPUTE REGULARIZED LOW RANK APPROXIMATION
%

param.niter           = n_iter;
param.regu_type_left  = '2ndOrderDiff_acc8';
param.regu_type_right = 'Tikh';
param.regu_left       = .006; 
param.regu_right      = .000;

fprintf('Computing a low rank approximation using BIRSVD ... \n');
[U_birsvd, D_birsvd, V_birsvd] = BIRSVD(Tmp, W, 2, param);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  FPCA : Ma et al. This method penalizes the neuclear norm.
%
%  NOTE: The FPCA algorithms computes the regularization parameter
%  and the number of iteration from the dimension and sparsity of
%  the problem.
%

fprintf('Computing a low rank approximation using FPCA ... \n');
Tmp_fpca_rec = FPCA(Tmp, W, 2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  FIDELITY WITHIN DATA, AND OUT OF DATA
%

Tmp_birsvd_rec  = U_birsvd * D_birsvd * V_birsvd';

err_birsvd_in  = norm((Tmp - Tmp_birsvd_rec).*W, 'fro') / norm(Tmp, 'fro');
err_birsvd_out = norm((Tmp - Tmp_birsvd_rec).*(1 -W), 'fro') / norm(Tmp, 'fro');

err_fpca_in  = norm((Tmp - Tmp_fpca_rec).*W, 'fro') / norm(Tmp, 'fro');
err_fpca_out = norm((Tmp - Tmp_fpca_rec).*(1 -W), 'fro') / norm(Tmp, 'fro');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  REPORT RESULTS
%

fprintf('\n');
fprintf('RESULTS:\n');
fprintf('\n');
fprintf('REGULARIZED LOW RANK APPROXIMATION \n\n')
fprintf('normalized error within observed data points:   %f\n', err_birsvd_in)
fprintf('normalized error outside observed data points:  %f\n', err_birsvd_out)
fprintf('\n');
fprintf('FPCA LOW RANK APPROXIMATION \n\n')
fprintf('normalized error within observed data points:   %f\n', err_fpca_in)
fprintf('normalized error outside observed data points:  %f\n', err_fpca_out)

%
%  CHANGE LOG:
%
%  Aug. 31, 2011 -- check if FPCA software is available.
%  Aug. 31, 2011 -- more added on detail printing.
%  Aug. 20, 2011 -- core function call set to upper level function BIRSVD.
%  Aug. 22, 2011 -- copied from demo_DOA_2.m, and first key in.

