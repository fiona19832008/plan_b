
%	SYNOPSIS:
%
%	Setup MATLAB script for the software. Use to ensure
%	proper path, availability of toolboxes etc.. 
%
%	Generate your own setup script, possibly by modifying this one
%	to ensure the path to SOURCE code.
%
%	AUTHOR:
%
%	saptarshi.das@univie.ac.at
%
%	LAST MODIFIED:
%
%	Jun. 03, 2010.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	GENERATE PATH
%

fprintf('Generating, and setting paths ... \n\n')
path(path, genpath('..'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	CHECK FOR TOOLBOX AVAILABILITY
%
%	Signal processing toolbox
%	Communication toolbox
%

% fprintf('Checking for toolbox availability... \n\n')
% if (license('test', 'communication_toolbox') == 1)
%   fprintf('Communication toolbox is available. \n\n')
% else
%   fprintf('Communication toolbox is not available. \n')
%   fprintf('Some of the demos and functions might not work :( \n\n')
% end
% 
% if (license('test', 'signal_toolbox') == 1)
%   fprintf('Signal processing toolbox is available. \n\n')
% else
%   fprintf('Signal processing toolbox is not available. \n')
%   fprintf('Some of the demos and functions might not work :( \n\n')
% end
