function b = A_prime_x(x, U, W, D)

%  SYNOPSIS:
%
%  A function to perform matrix vector multiplication with the
%  Hermitian transpose of the coefficient matrix of the least square problem 
%  that arises in "regularized low rank approximation of weighted data set".
%  The coefficient matrix is determined by three varablesm U, W, and D.
%  The vector to be multiplied is x.
%
%  INPUT:
%  
%  x       the vector to be multiplied.
%  U       the left singular vectors in the coeff matrix.
%  W       the weight matrix.
%  D       the matrix used for regularization.
% 
%  OUTPUT:
%
%  b       the matrix Hermetian transpose vector product.
%
%  NOTE:   a fast matrix vector multiplication with the matrix D is the
%          key. 
%
%  BUG REPORT:
%
%  saptarshi.das@univie.ac.at

[M, N] = size(W);
r = size(U, 2);

b_left = U'*reshape((W(:) .* x(1: M*N)), M, N);

x_re = reshape(x((M*N+1) :end), r, N);
b_right = D'*x_re.';
b_right = b_right.';


b = [b_left(:) + b_right(:)];
