function b = A_x(x, U, W, D)

%  SYNOPSIS:
%
%  A function to perform matrix vector multiplication with the
%  coefficient matrix of the least square problem that arises in 
%  "regularized low rank approximation of weighted data set".
%  The coefficient matrix is determined by three varablesm U, W, and D.
%  The vector to be multiplied is x.
%
%  INPUT:
%  
%  x       the vector to be multiplied.
%  U       the left singular vectors in the coeff matrix.
%  W       the weight matrix.
%  D       the matrix used for regularization.
% 
%  OUTPUT:
%
%  b       the matrix vector product.
%
%  NOTE:   a fast matrix vector multiplication with the matrix D is the
%          key. 
%
%  BUG REPORT:
%
%  saptarshi.das@univie.ac.at

[M, N] = size(W);
r = size(U, 2);

% U_kro = kron(eye(N), U);
x_re = reshape(x, r, N);
b_up = W .* (U * x_re);
b_lo = D*x_re.';
b_lo = b_lo.';

% b = [b_up(:); INT_D*x];
b = [b_up(:); b_lo(:)];
