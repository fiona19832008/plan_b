function [U, S, V, ERR] = BIRSVD(A, W, rnk, param_in)

%
%  CALLING SEQUENCE:
%
%    [U, S, V]  = BIRSVD(A, W, rnk, param_in)
%
%    returns component of a low rank (rnk) approximation [U, S, V] of an 
%    weighted data set, A accompanied with a weight matrix W. The
%    solution is regularized using a priori information that the approximants
%    (i.e. columns of U and V) are smooth. 
%
%    [U, S, V, ERR]  = BIRSVD(A, W, rnk, param_in) returns the norm of the
%    difference between successive approximations by the iterative method.
%
%  INPUT:
%
%    A            the data matrix.
%    W            weight of the data entries.
%    rnk          rank of the approximation in each iteration.
%    param_in     optional parameters, this is a MATLAB structure, and the
%                 following fields are available:
%                 1. 'niter' -- integer, number of iterations.      
%                 2. 'ini_method' -- initialization method, the following 
%                        options are avialable: 'zeroOneVectors', 
%                        'randOrthoNormal', 'polyOrthoNormal;.
%                 3. 'regu_type_left' -- type of regularization for left
%                        appriximant.  
%                 4. 'regu_type_right' -- type of regularization for right
%                        approximant.  
%                 5. 'regu_left' -- regularization intensity for left 
%                        approximants.  
%                 6. 'regu_right' -- regularization intensity for right 
%                        approximants.  
%
%  OUTPUT:
%
%    U            the left singular vectors (R of them).
%    S            R X R matrix with singular values in the diagonal.
%    V            the right singular vectors (R of them).
%
%  NOTE: 
%  
%    This implementation is done in order to explain the method in detail.
%    Several performance related steps are compromised. The implemented
%    algorithms still works with the same order of complexity. There are enough
%    'NOTES' within the code which suggest how to get performance gain.
%    Also, you can contact the authors for further help related to 
%    performance. 
%

%  AUTHOR / BUR REPORT:
%
%    saptarshi.das@univie.ac.at
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SET PARAMETERS, SET TO DEFAULT IF NOTHING IS PROVIDED
%

param.niter           =  30;
param.ini_method      = 'randOrthoNormal';
param.regu_type_left  = '2ndOrderDiff_acc8';
param.regu_type_right = '2ndOrderDiff_acc8';
param.regu_left       = .001;
param.regu_right      = .001;

if nargin == 0
  U = param;
  return 
end

if nargin == 4
  f_names = fieldnames(param_in);
  for i = 1 : length(f_names);
    f_name = f_names(i);
    param.(f_name{:}) = getfield(param_in, f_name{:});
  end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	DIMENSIONS AND SANITY CHECK
%
%	[N_row, N_cols]      dimension of the data set.

[M, N]     =  size(A);
if [M, N] ~=  size(W);
  error('dimMissMatch', 'Miss match in the dim. of data and mask');
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  COMPUTE REGULARIZATION MATRICES
%
%  ** NOTE: for practical purpose, do not create the 
%     interleaved matrix. Rather access the entries of
%     the interleaved matrices directly from D_U and D_V 
%

D_U    =  get_regularizing_matrix(M, param.regu_type_left);
D_V    =  get_regularizing_matrix(N, param.regu_type_right);
INT_DU =  zeros(M*rnk, M*rnk);
INT_DV =  zeros(N*rnk, N*rnk);
for r = 1:rnk
  INT_DU(r:rnk:M*rnk, r:rnk:M*rnk) = D_U;
  INT_DV(r:rnk:N*rnk, r:rnk:N*rnk) = D_V;
end
INT_DU = param.regu_left * sparse(INT_DU);
INT_DV = param.regu_right * sparse(INT_DV);
INT_DU = INT_DU'*INT_DU;
INT_DV = INT_DV'*INT_DV;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	INITIAL (0th) ITERATION TO COMPUTE THE LEFT SINGULAR VECTORS 
%
%	NOTE: many other method can be added for this purpose.
%

switch param.ini_method 
  case {'zeroOneVectors'}
    U         = zeros(M, rnk);
    idx       = [1:rnk] * floor(M/rnk);
    U(idx, :) = eye(rnk);
  case {'randOrthoNormal'}
    RND = rand(size(A, 1), rnk);
    U = orth(RND);
    clear RND;
  case {'polyOrthoNormal'}
    x = linspace(-1, 1, M);
    U = legendre_polys(rnk, x');
  otherwise
    disp('Proper method is not provided, using randOrthoNormal');
    U = full(A(:, [1:rnk]));
    U = orth(U);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  INITIALIZE SOME MATRICES
%
%  ** NOTE: create matrix A_w before the iterations only if
%     there is spare memory to hold it. This matrix A_w can
%     be used on the fly without creating explicitly, but this
%     will require an extra O(MN) operations per iteration. 
%
%  ** NOTE: for fast practical implementations do not create WT, and
%     A_wT, the elements of these matrices can be accessed well from
%     W, and A_w. 

A_w  = A .* W;
Y    = zeros(N, rnk);
X    = zeros(M, rnk);
WT   = W';
A_wT = A_w';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	ITERATION STEPS
%
%	1. Find right singular vectors with singualar values (S_Vstar).
%	2. Orthogonalize (S_Vstar). 
%	3. Find left singular vectors U. 
%	4. Orthogonalize U.

if nargout == 4
  recon = zeros(M, N);
  ERR = [];
end

for iter = 1 : param.niter 

  %
  % Computing the right approximants from the left approximants.
  % 'R' is right hand side, and 'L' is coefficient matrix 
  % Since 'L' is PSD and banded, we use Cholesky.
  % Solve with forward and back substitution. 
  % Finally orthonormalize.
 
  R = reshape(U' * A_w, N*rnk, 1);
  L = sparse([]);
  for n = 1 : N
    L = blkdiag(L, U'*(repmat(W(:,n), 1, rnk).*U));
  end
  L_L = chol(L +  INT_DV);

  Y = L_L \ (L_L' \ R);
  Y = reshape(Y, rnk, N);

  [U_dummy, S, V] = svds(Y, rnk);

  % Fix sign of V, from signs of U_dummy. 
  %
  % NOTE: this step is not necessary, its kept just to
  % compare the results with MATLAB's svd. This step is required 
  % because SVD is unique upto a sign.
  %
  % NOTE: U_dummy is not required otherwise. So for practical 
  % implementations, do not compute U_dummy. 
  %  

  for r = 1:rnk
    [a, I] = max(abs(U_dummy(:, r)));
    V(:, r) = V(:, r) * sign(U_dummy(I(1), r));
  end

  % Computing left approximants from the right. 
  % 'R' is right hand side, and 'L' is coefficient matrix 
  % Since 'L' is PSD and banded, we use Cholesky.
  % Solve with forward and back substitution. 
  % Finally orthonormalize.

  R = reshape(V' * A_wT, M*rnk, 1);
  L = sparse([]);
  for m = 1 : M
    L = blkdiag(L, V'*(repmat(WT(:,m), 1, rnk).*V));
  end
  [L_L, U_L] = lu(L +  INT_DU);
  X = reshape(U_L \ (L_L \ R), rnk, M);

  [U, R_dummy] = qr(X', 0);

  % error from last iteration
  %
  % NOTE:One can use a certain threshold for ERR, 
  % to stop the algorithm. Check the commented lines below.

  if nargout == 4
    this_recon = U*S*V';
    ERR = [ERR; norm(recon - this_recon, 'fro')];
    recon = this_recon;
  end
end


%  CHANGE LOG:
%
%  ** Jan. 23, 2011 -- extra inputs made through parameter struct.
%  ** Jan. 22, 2011 -- the help lines are mofied.
%  ** Dec. 12, 2010 -- all the performance related notes are added.
%  ** Aug. 07, 2011 -- sign fixed so as to make as per with MATLAB. 
%  ** Jul. 29, 2011 -- coding begins.
