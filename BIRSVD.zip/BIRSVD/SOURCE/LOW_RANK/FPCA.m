function X = FPCA(A, W, r)

% X = FPCA(A, W, r) computes a rank "r" approximation of an incomplete data 
% set A, with sampling patterns specified in matrix W with binary entries
% using Fixed Point Continuation Methods based on Approximate SVD (FPCA) for 
% Matrix Completion Problem. 
%
% NOTE: this is just a wrapper over the main codes of FPCA developed by
% S. Ma. This wrapper is made to make the call easy, and at par with other
% functions of BIRSVD.
%
% References:
% Details about the FPCA algorithm can be found in: 
% 
%         @article{ma2011,
%           title={Fixed point and Bregman iterative methods for matrix 
%           rank minimization},
%           author={Ma, S. and Goldfarb, D. and Chen, L.},
%           journal={Mathematical Programming},
%           volume={128},
%           number={1},
%           pages={321--353},
%           year={2011},
%           publisher={Springer}
%         }

%
%  AUTHOR / BUG REPORT:
%
%  saptarshi.das@univie.ac.at

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  [m, n]    size of the data matrix.
%  p         number of samples.
%  sr        sampling ratio.
%  fr        is the freedom of set of rank-r matrix. 
%  maxr      is the maximum rank one can recover with p samples, which 
%            is the max rank to keep fr < 1.

[m, n] = size(A);
p = nnz(W);
sr = nnz(W) / (m*n) ;

fr = r*(m+n-r)/p; 
maxr = floor(((m+n)-sqrt((m+n)^2-4*p))/2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  idx     linear index of the samples. 
%  b       the vectorized form of the samples. 

idx  = find(W);
b    = reshape(A, m*n, 1); 
b    = b(idx); 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   opts    opts get parameters for FPCA. 
%   Out     stores the results of the core FPCA algorithm.
%   X       the compted matrix (return variable).

opts = get_opts_FPCA(A,maxr,m,n,sr,fr); 
Out  = FPCA_MatComp(m,n,idx,b,opts);
X    = Out.x;


% CHANGE LOG:
%
% Aug. 31, 2011 -- copied FPCA/One_run.m by S. Ma, and modified to function.
