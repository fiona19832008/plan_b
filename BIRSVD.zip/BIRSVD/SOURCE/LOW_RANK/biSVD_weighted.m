function [U, S, V] = biSVD_weighted(A, W, rnk, param_in)

%
%  CALLING SEQUENCE:
%
%    [U, S, V]  = biSVD_weighted(A, W, rnk, param_in)
%
%  SYNPOSIS:
%
%    computes a low rank (rnk) approximation of an weighted data set, A, by
%    biSVD iterations. In the 0th iteration, the left 
%    singular vector is computed by the initialization method, 'ini_method', 
%    provided. Further on each step, the left right singular vectors and
%    computed from left ones, and vice-versa. At each iteration, the left
%    and right singular values are orthogonalized.
%    The iteration is done N_iter times, and the weights are provided
%    through the matrix 'W', which is a file with binary entries. 
%
%  NOTE: 
%  
%    This implementation is done in order to explain the method in detail.
%    Several performance related steps are compromised. The implemented
%    algorithms still works with the same order of complexity. There are enough
%    'NOTES' within the code which suggest how to get performance gain.
%    Also, you can contact the authors for further help related to 
%    performance. 
%
%
%  INPUT:
%
%    A            the data matrix.
%    W            weight of the data entries.
%    rnk          rank of the approximation in each iteration.
%    param_in     optional parameters, this is a MATLAB structure, and the
%                 following fields are available:
%                 1. 'niter' -- integer, number of iterations.      
%                 2. 'ini_method' -- initialization method, the following 
%                        options are avialable: 'zeroOneVectors', 
%                        'randOrthoNormal', 'polyOrthoNormal;.
%
%  OUTPUT:
%
%    U            the left singular vectors (R of them).
%    S            R X R matrix with singular values in the diagonal.
%    V            the right singular vectors (R of them).
%

%  AUTHOR / BUR REPORT:
%
%    saptarshi.das@univie.ac.at
%

%  LAST CHANGE (DATE/NOTE):
%
%    Jul. 09, 2010 / weight files attached.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  SET PARAMETERS, SET TO DEFAULT IF NOTHING IS PROVIDED
%

param.niter      =  30;
param.ini_method = 'randOrthoNormal';

if nargin == 0
  U = param;
  return 
end

if nargin == 4
  f_names = fieldnames(param_in);
  for i = 1 : length(f_names);
    f_name = f_names(i);
    param.(f_name{:}) = getfield(param_in, f_name{:});
  end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	DIMENSIONS AND SANITY CHECK
%
%	[N_row, N_cols]      dimension of the data set.

[M, N]     =  size(A);
if [M, N] ~=  size(W);
  error('dimMissMatch', 'Miss match in the dim. of data and mask');
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	INITIAL (0th) ITERATION TO COMPUTE THE LEFT SINGULAR VECTORS 
%
%	NOTE: many other method can be added for this purpose.
%

switch param.ini_method 
  case {'zeroOneVectors'}
    U         = zeros(M, rnk);
    idx       = [1:rnk] * floor(M/rnk);
    U(idx, :) = eye(rnk);
  case {'randOrthoNormal'}
    RND = rand(size(A, 1), rnk);
    U = orth(RND);
    clear RND;
  case {'polyOrthoNormal'}
    x = linspace(-1, 1, M);
    U = legendre_polys(rnk, x');
  otherwise
    disp('Proper method is not provided, using randOrthoNormal');
    U = full(A(:, [1:rnk]));
    U = orth(U);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	TODO: COMMENT ALL THESE

sig2 = 1e-6;
A_w  = A .* W;
Y    = zeros(N, rnk);
X    = zeros(M, rnk);
WT   = W';
A_wT = A_w';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	ITERATION STEPS
%
%	1. Find right singular vectors with singualar values (S_Vstar).
%	2. Orthogonalize (S_Vstar). 
%	3. Find left singular vectors U. 
%	4. Orthogonalize U.

for iter = 1 : param.niter 

  % update V from U. 
  for n = 1 : N
    R = U' * A_w(:, n);
    L = U' * (repmat(W(:,n), 1, rnk) .* U);
    Y(n, :) = [(L'*L + sig2*(1 - sum(W(:, n))/M).^2 *eye(rnk)) \ (L' * R)]';
  end

  [U_dummy, S, V] = svds(Y', rnk);

  % Fix sign of V, from signs of U_dummy. 
  for r = 1:rnk
    [a, I] = max(abs(U_dummy(:, r)));
    V(:, r) = V(:, r) * sign(U_dummy(I(1), r));
  end

  % update U from V
  for m = 1 : M
    R = V' * A_wT(:, m); 
    L = V' * (repmat(WT(:,m), 1, rnk) .* V);
    X(m, :) = (L'*L + sig2*(1 - sum(WT(:, m))/N) * eye(rnk)) \ (L' * R);
  end

  [U, R_dummy] = qr(X, 0);

end

