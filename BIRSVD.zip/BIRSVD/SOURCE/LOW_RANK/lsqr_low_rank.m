function x = lsqr_low_rank(A, A_prime, b, numiter, U, W, D, x0)

%  CALLING SEQUENCE:
%  
%  x = lsqr_low_rank(A, A_prime, b, numiter, U, W, D, x0)
%  
%  SYNOPSIS:
%
%  solves the least squares problem  min || Ax-b || that arises in the
%  "weighted low rank approximation with weighted data" problem for the 
%  vector x via the LSQR algorithm of Saunders and Paige.  numiter is 
%  the number of iterations to use. This implementation uses the operators
%  A and A' as black boxes. Post-multipication of vectors with A
%  or A' is acomplished by using the function handle.
%  
%  Input parameters:  
%
%   A		function handle for post multipication Ax
%   A_prime	function handle for post multipication A*x
%   b		the vector on right hand side   
%   numiter     the number of iterations
%   U           the left low rank approximants          
%   W           the weight matrix
%   D           the matrix for regularization
%   x0		first initial guess (optional argument, default set to 0)  
%  
%  Output parameters:  
%
%   x		the approximate solutions, numiter of them, as columns
%		of x
%

%  Written by Ben Bunck, Jan. 16, 2003
%  Last modified, April. 16, 2003
%
%  Modified by Saptarshi Das, Oct. 07, 2008
%  Last modified, Jan. 22, 2011 
%  

if nargin == 8
  b = b - feval(A, x0, U, W, D);
  x_aff = x0;
end

beta = norm(b);
u = b/beta;
phibar = beta;

v = feval(A_prime, u, U, W, D);
alpha = norm(v);
v = v/alpha;
rhobar = alpha;
w = v;

x0 = zeros(size(v));
x = zeros(length(v), numiter);


%      iterations

for j = 1 : numiter

%
% Constructing the bidiagonalization
%

     u = feval(A, v, U, W, D) -alpha*u;
     beta = norm(u);
     u = u/beta;

     v = feval(A_prime, u, U, W, D) - beta*v;
     alpha = norm(v);
     v = v/alpha;

%
% Applying the next orthog. transformation
%
     
     rho = sqrt(rhobar^2 + beta^2);
     c = rhobar/rho;
     s = beta/rho;
     theta = s*alpha;

     rhobar = -c*alpha;
     phi = c*phibar;
     phibar = s*phibar;

%
% Updating x, w
%
    
     x0 = x0 + (phi/rho)*w;
     w = v - (theta/rho)*w;
     x(:, j) = x0;         

end

if nargin == 8
  x = x + repmat(x_aff, 1, numiter);
end

