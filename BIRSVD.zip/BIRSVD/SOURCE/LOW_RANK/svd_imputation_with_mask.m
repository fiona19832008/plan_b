function [U, S, V]  = ...
             svd_imputation_with_mask(data, mask, N_iter, R, ini_method)

%
%  CALLING SEQUENCE:
%
%    [U, S, V]  = svd_imputation_with_mask(data, mask, N_iter, R, ini_method)
%
%  SYNPOSIS:
%
%    computes a low rank (R) approximation of an incomplete data set by
%    imputation. In the 0th iteration, the missing values are replaced using
%    initialization method, 'ini_method', provided. Further on each step
%    a low rank (R) approximation is done, and the missing values are
%    replaced by the low rank approximations at those data points. The
%    iteration is done N_iter times, and the missing values are provided
%    through the 'mask', which is a file with binary entries. 
%
%  INPUT:
%
%    data         the data matrix.
%    mask         mask with binary entries, 0 denote missing entry.
%    N_iter       number of iterations.
%    R            rank of the approximation in each iteration.
%    ini_method   initial method for approximating missing values in 0th step.
%                 Following options are available: 'columnMean', 'rowMean', 
%                 'totalMean', 'allZeros'.
%
%  OUTPUT:
%
%    U            the left singular vectors (R of them).
%    S            R X R matrix with singular values in the diagonal.
%    V            the right singular vectors (R of them).
%
%  AUTHOR / BUR REPORT:
%
%    saptarshi.das@univie.ac.at
%
%  LAST CHANGE (DATE/NOTE):
%
%    Jul. 09, 2010 / first coding.
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	DIMENSIONS AND SANITY CHECK
%
%	[N_row, N_cols]      dimension of the data set.

[N_rows, N_cols]     =  size(data);
if [N_rows, N_cols] ~= size(mask);
  error('dimMissMatch', 'Miss match in the dim. of data and mask');
end 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	INITIAL (0th) ITERATION OF IMPUTATION 
%
%	NOTE: many other method can be added for this purpose.
%	TODO: add similar method with median.

switch ini_method 
  case {'allZeros'}
    data = data .* mask;
  case {'columnMean'}
    rowMean = sum(data .* mask, 1) ./ sum(mask, 1); 
    data = data + (1 - mask) .* repmat(rowMean, N_rows, 1);
  case {'rowMean'}
    colMean = sum(data .* mask, 2) ./ sum(mask, 2); 
    data = data + (1 - mask) .* repmat(colMean, 1, N_cols);
  case {'totalMean'}
    totalMean = sum(sum(data .* mask)) ./ sum(sum(mask)); 
    data = data + (1 - mask) .* repmat(totalMean, N_rows, N_cols);
  otherwise
    disp('Proper method is not provided, using allZeros');
    data = data .* mask;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	ITERATION STEPS
%
%	1. compute SVD.
%	2. Replace missing data with low rank approximation. 
%	3. do SVD again, 

[U, S, V]  =  svds(data, R);
for iter = 1 :  N_iter
  data = data + (mask -1) .* (U*S*V');
  [U, S, V]  =  svds(data, R);
end

