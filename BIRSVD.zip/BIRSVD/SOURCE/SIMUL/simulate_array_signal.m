
function A = simulate_array_signal(nA, dA, nT, lambda, P, theta, sigma)

%
%  CALLING SEQUENCE:
%
%    A = simulate_array_signal(nA, dA, nT, lambda, P, theta, sigma);
%
%  SYNOPSIS:
%
%    This function simulates data for an array of antenna with 'nA' 
%    antenna spaced 'd' apart. Total 'nT' data points are created at.
%    The source signals emmit frequencies with wavelength
%    lambda, and their potentials and angle of arrival are 'P' and 
%    'theta' respectively. Finally an complex additive Gaussian noise of 
%    standard deviation 'sigma' is added to the signal entries.  
%
%  INPUT:
%
%    nA            number of sensors (antenna) in the array.
%    dA            distance between sensors (antenna).
%    nT            total number of time points. 
%    lambda        wavelength of frequency emitted by the sources.
%    P             potentials of each source (vector).
%    theta         angle of arrival of each rource (vector) in "DEGREE". 
%    sigma         standard deviation of the additive white Gaussian noise.
%
%  OUTPUT:
%
%    A      samples at 'nA' antenna array at 'nT' time points. 
%
%  BUG REPORT:
%
%    saptarshi.das@univie.ac.at

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  D      index of the array sensors
%  A      return matrix with sensor array data

D = [0:nA-1];
A = -sqrt(-1)*(2*pi*dA/lambda)*cos(theta*pi/180)*D;
A = exp(A);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  src_wave      random source wave
%

src_wave = rand(nT, length(P));
src_wave = 2*round(src_wave) - 1;
src_wave = src_wave * diag(P);

A = src_wave*A;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%  ADDITIVE NOISE
%

no = sqrt(sigma/2)*(randn(size(A)) + sqrt(-1)*randn(size(A)));
A = A + no;
