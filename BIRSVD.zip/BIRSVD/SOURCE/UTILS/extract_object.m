function [obj_out, mask] = extract_object(im, perc_lo, perc_up)

%
%	SYNOPSIS:
%
%	This function extract bright object from image and set it to NaN.
%	The bright objects are extracted once the light intensity crosses
%	a certain threshold. With this mechanism, the artifact due to
%	cosmic rays, hot pixcels and others are avioded.
%	other  
%	
%	INPUT:
%
%	im		image with the objects
%
%	perc_lo		percentile below which the pixels will represent 
%			bright objects..
%
%	perc_up		percentile above which the pixels will represent 
%			bright objects..
%
%	OUTPUT:
%	
%	obj_out		object extracted image.
%
%	mask		the object mask.
%
%	BUG REPORT:
%
%	For help and bug report please contact at
%	saptarshi.das@univie.ac.at
%
%	LAST MODIFIED:
%
%	02/08/2010
%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	INITIALIZE OUTPUT	
%	
%	[row_tot, col_tot]	total number of rows and cols in the image.
%	obj_out			Output image.

[row_tot, col_tot] = size(im);
obj_out = im;
clear im;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	FIND CUTOFF MAGNITUDE, FIND PIXEL BELOW CUTOFF 
%
%	cut_off_mag_lo	lower cut off magnitude at specified percentile.
%	cut_off_mag_up	upper cut off magnitude at specified percentile.
%	[row col val]	positions which do not correspond to bringt objects.
%	mask_lo		mask that leave out dark objects (noise).
%	mask_up		mask that leave out bright objects.

cut_off_mag_lo = prctile(obj_out(:), perc_lo);
cut_off_mag_up = prctile(obj_out(:), perc_up);
[row, col, val] = find(obj_out > cut_off_mag_lo);
mask_lo = sparse(row, col, val, row_tot, col_tot);
[row, col, val] = find(obj_out < cut_off_mag_up);
mask_up = sparse(row, col, val, row_tot, col_tot);

mask = mask_lo .* mask_up;
obj_out = obj_out;

