function D = get_regularizing_matrix(N, regu_type)

%
%  CALLING SEQUENCE:
%
%    D = get_regularizing_matrix(N, regu_type)
%
%  SYNPOSIS:
%
%    Returns regualrizing matrix of different types for penalizing the
%    non-smoothness of the solution. 
%
%  INPUT:
%
%    N            size of the solution.
%
%    regu_type    the type of regularization required.
%                 Following options are available: 'columnMean', 'rowMean', 
%                 'totalMean', 'allZeros'.
%
%  OUTPUT:
%
%    D            the regularizing matrix. 
%
%  AUTHOR / BUR REPORT:
%
%    saptarshi.das@univie.ac.at
%
%  LAST CHANGE (DATE/NOTE):
%
%    Aug. 05, 2010 / Added accuray 6, and 8.
%

if strcmp(regu_type, 'Tikh')
  D = eye(N, N);
end

if strcmp(regu_type, '2ndOrderDiff_acc2')
  D = diag(.5*ones(N-1, 1), 1) + ...
      diag(-1*ones(N, 1), 0) + ...
      diag(.5*ones(N-1, 1), -1); 
  
  D(1, 2)   = 1;
  D(N, N-1) = 1;
  D = sparse(D);
end

if strcmp(regu_type, '2ndOrderDiff_acc4')
  D = ...
      diag((-1/12)*ones(N-2, 1), 2) + ...
      diag((4/3)*ones(N-1, 1), 1) + ...
      diag(-(5/2)*ones(N, 1), 0) + ...
      diag((4/3)*ones(N-1, 1), -1) + ...
      diag((-1/12)*ones(N-2, 1), -2) ...
      ; 
  D(1, 1:3)   = [-5/2, 8/3, -1/6];
  D(2, 1:4)   = [4/3, -5/2, 4/3, -1/6];
  D(N, (N-2):N) = fliplr([-5/2, 8/3, -1/6]) ;
  D(N-1, (N-3):N) = fliplr([4/3, -5/2, 4/3, -1/6]) ;
  D = sparse(D);
end

if strcmp(regu_type, '2ndOrderDiff_acc6')
  D = ...
      diag((1/90)*ones(N-3, 1), 3) + ...
      diag((-3/20)*ones(N-2, 1), 2) + ...
      diag((3/2)*ones(N-1, 1), 1) + ...
      diag(-(49/18)*ones(N, 1), 0) + ...
      diag((3/2)*ones(N-1, 1), -1) + ...
      diag((-3/20)*ones(N-2, 1), -2) + ...
      diag((1/90)*ones(N-3, 1), -3) ...
      ; 
  D(1, 1:4)   = [-49/18, 3, -3/10, 1/45];
  D(2, 1:5)   = [3/2, -49/18, 3/2, -3/10, 1/45];
  D(3, 1:6)   = [-3/20, 3/2, -49/18, 3/2, -3/20, 1/45];

  D(N, (N-3):N)     = fliplr([-49/18, 3, -3/10, 1/45]);
  D(N-1, (N-4):N)   = fliplr([3/2, -49/18, 3/2, -3/10, 1/45]);
  D(N-2, (N-5):N)   = fliplr([-3/20, 3/2, -49/18, 3/2, -3/20, 1/45]);

  D = sparse(D);
end

if strcmp(regu_type, '2ndOrderDiff_acc8')
  D = ...
      diag((-1/560)*ones(N-4, 1), 4) + ...
      diag((8/315)*ones(N-3, 1), 3) + ...
      diag((-1/5)*ones(N-2, 1), 2) + ...
      diag((8/5)*ones(N-1, 1), 1) + ...
      diag(-(205/72)*ones(N, 1), 0) + ...
      diag((8/5)*ones(N-1, 1), -1) + ...
      diag((-1/5)*ones(N-2, 1), -2) + ...
      diag((8/315)*ones(N-3, 1), -3) + ...
      diag((-1/560)*ones(N-4, 1), -4) ...
      ; 

  D(1, 1:5)   = [-205/72, 16/5, -2/5, 16/315, -1/280];
  D(2, 1:6)   = [8/5, -205/72, 8/5, -2/5, 16/315, -1/280];
  D(3, 1:7)   = [-1/5, 8/5, -205/72, 8/5, -1/5, 16/315, -1/280];
  D(4, 1:8)   = [8/315, -1/5, 8/5, -205/72, 8/5, -1/5, 8/315, -1/280];

  D(N,   (N-4):N)   = fliplr([-205/72, 16/5, -2/5, 16/315, -1/280]);
  D(N-1, (N-5):N)   = fliplr([8/5, -205/72, 8/5, -2/5, 16/315, -1/280]);
  D(N-2, (N-6):N)   = fliplr([-1/5, 8/5, -205/72, 8/5, -1/5, 16/315, -1/280]);
  D(N-3, (N-7):N)   = fliplr([8/315, -1/5, 8/5, -205/72, 8/5, -1/5, ...
                              8/315, -1/280]);

  D = sparse(D);
end

%% TODO this is not properly implemented :(
if strcmp(regu_type, 'LowPass')
  D = fft(eye(N)); 
  W = zeros(1, N);
  W(7:N) = sin(pi*[0:N-7]/(N - 7)); 
  D = diag(W)* D;
  D = sparse(D);
end

D = N*D;
