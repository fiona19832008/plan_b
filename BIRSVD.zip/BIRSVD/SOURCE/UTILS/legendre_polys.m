function y = legendre_polys(m, x)
%
%  Synopsis:
%                 y = legendre_polys(m, x);
% 
% 
%       Description:
%                 
%
%       This function evaluates m first Legendre polynomials
%       polynomial at the vector x.
% 
%       Input
% 
%       m       the number of polynomials required
% 
%       x       the vector of arguments
% 
%       Output
% 
%       y       the values of the Legendre polynomials at the nodes,
%		the values of P_{k-1} lie in the k-th column
% 
%       T. Hrycak, WSU, 12/9/2001
%       last modified   12/9/2001
%
%
%       



n = length(x);
y = zeros(n,m);

%     
%     initializing
%

y(:,1) = ones(size(x));
y(:,2) = x;

%     
%     conducting the recursion.


for k = 2:m-1
    tmp = (2*k-1)*x.*y(:,k)-(k-1)*y(:,k-1);
    y(:,k+1) = tmp/k;
end

%       trimming to size (needed only for m < 2)

y = y(:,1:m);
