%
%	Script for finishing plotting in a human readable form
%
%	Written by T. Hrycak, Nov. 7, 2007. 
%	Last modified, Nov. 7, 2007.
%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	getting the limits and tic locations
%
grid on

xlimits = get(gca, 'XLim');
ylimits = get(gca, 'YLim');

xticks = get(gca, 'XTick');
yticks = get(gca, 'YTick');

grid off

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	replotting the grid
%

tmp_no = length(get(gca,'Children'));

a = .9;
for tmp = xticks
    line([tmp tmp], ylimits, 'Color', [a a a])
end

for tmp = yticks
    line(xlimits, [tmp tmp], 'Color', [a a a])
end

%       restoring the old limits

axis([xlimits ylimits])

%	hiding the grid lines under the previously plotted objects

tmp_children = get(gca,'Children');
set(gca, 'Children', circshift(tmp_children, tmp_no))

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%	setting fonts for the figure and the title
%

set(gca, 'FontSize', 12, 'FontWeight','bold')

if exist('title_string')
   title(title_string, 'FontSize', 16, 'FontWeight', 'bold')
end
